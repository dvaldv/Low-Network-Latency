#!/system/bin/sh

sleep 20

echo 1 > /proc/sys/net/ipv4/tcp_low_latency
cmd wifi force-low-latency-mode enabled