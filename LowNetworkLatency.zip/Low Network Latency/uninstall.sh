#!/system/bin/sh

echo 0 > /proc/sys/net/ipv4/tcp_low_latency
cmd wifi force-low-latency-mode disabled